package com.instafarm.util;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.Formatting;

public enum FarmDef {
    BEETROOT_FARM("beetroot_farm","Beetroot Farm","Pancar",Items.BEETROOT,Formatting.DARK_RED,"crop_farms","Otomatik pancar hasatı.",s("beetroot_farm",-9,-1,0,"none"),s("beetroot_farm",1,-1,-9,"270"),s("beetroot_farm",-9,-1,-14,"180"),s("beetroot_farm",-14,-1,-9,"90")),
    BREAD_FARM("bread_farm","Bread Farm","Ekmek",Items.BREAD,Formatting.YELLOW,"crop_farms","Otomatik ekmek üretimi.",s("bread_farm",-9,-1,0,"none"),s("bread_farm",1,-1,-9,"270"),s("bread_farm",-9,-1,-14,"180"),s("bread_farm",-14,-1,-9,"90")),
    CARROT_FARM("carrot_farm","Carrot Farm","Havuç",Items.CARROT,Formatting.GOLD,"crop_farms","Otomatik havuç çiftliği.",s("carrot_farm",-9,-1,0,"none"),s("carrot_farm",1,-1,-9,"270"),s("carrot_farm",-9,-1,-14,"180"),s("carrot_farm",-14,-1,-9,"90")),
    POTATO_FARM("potato_farm","Potato Farm","Patates",Items.POTATO,Formatting.GOLD,"crop_farms","Otomatik patates çiftliği.",s("potato_farm",-9,-1,0,"none"),s("potato_farm",1,-1,-9,"270"),s("potato_farm",-9,-1,-14,"180"),s("potato_farm",-14,-1,-9,"90")),
    MELON_FARM("melon_farm","Melon Farm","Karpuz",Items.MELON_SLICE,Formatting.GREEN,"crop_farms","Otomatik karpuz çiftliği.",s("melon_farm",-14,-1,0,"none"),s("melon_farm",0,-1,-14,"270"),s("melon_farm",-14,-1,-21,"180"),s("melon_farm",-21,-1,-14,"90")),
    PUMPKIN_FARM("pumpkin_farm","Pumpkin Farm","Balkabağı",Items.PUMPKIN,Formatting.GOLD,"crop_farms","Otomatik balkabağı çiftliği.",s("pumpkin_farm",-14,-1,0,"none"),s("pumpkin_farm",0,-1,-14,"270"),s("pumpkin_farm",-14,-1,-21,"180"),s("pumpkin_farm",-21,-1,-14,"90")),
    MELON_PUMPKIN_FARM("melon_pumpkin_farm","Melon & Pumpkin Farm","Karpuz+Balkabağı",Items.MELON_SLICE,Formatting.GREEN,"crop_farms","Karpuz ve balkabağı üretimi.",s("melon_pumpkin_farm",-20,-1,1,"none"),s("melon_pumpkin_farm",1,-1,-20,"270"),s("melon_pumpkin_farm",-20,-1,-13,"180"),s("melon_pumpkin_farm",-13,-1,-20,"90")),
    BAMBOO_FARM("bamboo_farm","Bamboo Farm","Bambu",Items.BAMBOO,Formatting.GREEN,"nature_farms","Otomatik bambu çiftliği.",s("bamboo_farm",-6,-1,1,"none"),s("bamboo_farm",1,-1,-6,"270"),s("bamboo_farm",-6,-1,-16,"180"),s("bamboo_farm",-16,-1,-6,"90")),
    CACTUS_FARM("cactus_farm","Cactus Farm","Kaktüs",Items.CACTUS,Formatting.DARK_GREEN,"nature_farms","Otomatik kaktüs çiftliği.",s("cactus_farm",-10,-1,1,"none"),s("cactus_farm",1,-1,-10,"270"),s("cactus_farm",-10,-1,-22,"180"),s("cactus_farm",-22,-1,-10,"90")),
    KELP_FARM("kelp_farm","Kelp Farm","Yosun",Items.KELP,Formatting.DARK_AQUA,"nature_farms","Su altı yosun çiftliği.",s("kelp_farm",-12,-1,0,"none"),s("kelp_farm",0,-1,-12,"270"),s("kelp_farm",-12,-1,-18,"180"),s("kelp_farm",-18,-1,-12,"90")),
    CANES_FARM("canes_farm","Sugar Cane Farm","Şeker Kamışı",Items.SUGAR_CANE,Formatting.AQUA,"nature_farms","Otomatik şeker kamışı.",s("canes_farm",-6,-1,1,"none"),s("canes_farm",1,-1,-6,"270"),s("canes_farm",-6,-1,-16,"180"),s("canes_farm",-16,-1,-6,"90")),
    HONEY_FARM("honey_farm","Honey Farm","Bal",Items.HONEY_BOTTLE,Formatting.GOLD,"nature_farms","Otomatik bal çiftliği.",s("honey_farm",-6,-1,0,"none"),s("honey_farm",0,-1,-7,"270"),s("honey_farm",-7,-1,-12,"180"),s("honey_farm",-12,-1,-6,"90")),
    BONE_MEAL_FARM("bone_meal_farm","Bone Meal Farm","Kemik Unu",Items.BONE_MEAL,Formatting.WHITE,"nature_farms","Otomatik kemik unu.",s("bone_meal_farm",-14,-1,1,"none"),s("bone_meal_farm",1,-1,-14,"270"),s("bone_meal_farm",-14,-1,-16,"180"),s("bone_meal_farm",-16,-1,-14,"90")),
    TWISTING_FARM("twisting_farm","Twisting Vines Farm","Kıvrımlı Asma",Items.TWISTING_VINES,Formatting.DARK_AQUA,"nature_farms","Kıvrımlı asma çiftliği.",s("twisting_farm",-6,-1,1,"none"),s("twisting_farm",1,-1,-6,"270"),s("twisting_farm",-6,-1,-16,"180"),s("twisting_farm",-16,-1,-6,"90")),
    WEEPING_FARM("weeping_farm","Weeping Vines Farm","Ağlayan Asma",Items.WEEPING_VINES,Formatting.DARK_RED,"nature_farms","Ağlayan asma çiftliği.",s("weeping_farm",-6,-1,1,"none"),s("weeping_farm",1,-1,-6,"270"),s("weeping_farm",-6,-1,-16,"180"),s("weeping_farm",-16,-1,-6,"90")),
    COBBLESTONE_FARM("cobblestone_farm","Cobblestone Farm","Çakıl Taşı",Items.COBBLESTONE,Formatting.GRAY,"block_farms","TNT ile çakıl taşı üretimi.",s("tnt_stone_farm",-20,-1,1,"none"),s("tnt_stone_farm",1,-1,-20,"270"),s("tnt_stone_farm",-20,-1,-41,"180"),s("tnt_stone_farm",-41,-1,-20,"90")),
    STONE_FARM("stone_farm","Stone Farm","Taş",Items.STONE,Formatting.GRAY,"block_farms","Otomatik taş çiftliği.",s("stone_farm",0,0,0,"none"),s("stone_farm",0,0,0,"none"),s("stone_farm",0,0,0,"none"),s("stone_farm",0,0,0,"none")),
    BASALT_FARM("basalt_farm","Basalt Farm","Bazalt",Items.BASALT,Formatting.DARK_GRAY,"block_farms","TNT ile bazalt üretimi.",s("tnt_basalt_farm",-20,-1,1,"none"),s("tnt_basalt_farm",1,-1,-20,"270"),s("tnt_basalt_farm",-20,-1,-41,"180"),s("tnt_basalt_farm",-41,-1,-20,"90")),
    WOOL_FARM("wool_farm","Wool Farm","Yün",Items.WHITE_WOOL,Formatting.WHITE,"block_farms","Otomatik yün çiftliği.",s("wool_farm",-11,-1,1,"270"),s("wool_farm",1,-1,-11,"180"),s("wool_farm",-11,-1,-8,"90"),s("wool_farm",-8,-1,-11,"none")),
    MANUAL_TREE_FARM("manual_tree_farm","Manual Tree Farm","Odun (Manuel)",Items.OAK_LOG,Formatting.DARK_GREEN,"block_farms","Manuel ağaç çiftliği.",s("manual_tree_farm",-12,-1,1,"none"),s("manual_tree_farm",1,-1,-12,"270"),s("manual_tree_farm",-12,-1,-18,"180"),s("manual_tree_farm",-18,-1,-12,"90")),
    AUTO_TREE_FARM("auto_tree_farm","Auto Tree Farm","Otomatik Odun",Items.OAK_LOG,Formatting.GREEN,"block_farms","Otomatik ağaç çiftliği. Islak biyomda kullanın!",s("auto_tree_farmz",-10,-1,1,"none"),s("auto_tree_farmx",1,-1,-10,"none"),s("auto_tree_farmx",-10,-1,-21,"270"),s("auto_tree_farmz",-21,-1,-10,"90")),
    IRON_FARM("iron_farm","Iron Farm","Demir",Items.IRON_INGOT,Formatting.WHITE,"ore_farms","Köy-Golem ile demir. 130 blok köyden uzak!",s("iron_farm",-7,-1,1,"none"),s("iron_farm",1,-1,-8,"270"),s("iron_farm",-8,-1,-12,"180"),s("iron_farm",-12,-1,-7,"90")),
    GOLD_FARM("gold_farm","Gold Farm","Altın",Items.GOLD_INGOT,Formatting.YELLOW,"ore_farms","Nether portallı altın çiftliği.",s("gold_farm",-15,0,1,"none"),s("gold_farm",1,0,-15,"270"),s("gold_farm",-15,0,-29,"180"),s("gold_farm",-29,0,-15,"90")),
    COW_FARM("cow_farm","Cow Farm","Et & Deri",Items.BEEF,Formatting.DARK_RED,"mob_farms","Otomatik inek çiftliği.",s("cow_farm",-9,-1,0,"none"),s("cow_farm",0,-1,-9,"270"),s("cow_farm",-9,-1,-11,"180"),s("cow_farm",-11,-1,-9,"90")),
    PIG_FARM("pig_farm","Pig Farm","Domuz Eti",Items.PORKCHOP,Formatting.LIGHT_PURPLE,"mob_farms","Otomatik domuz çiftliği.",s("pig_farm",-9,-1,0,"none"),s("pig_farm",0,-1,-9,"270"),s("pig_farm",-9,-1,-11,"180"),s("pig_farm",-11,-1,-9,"90")),
    SHEEP_FARM("sheep_farm","Sheep Farm","Yün & Et",Items.WHITE_WOOL,Formatting.WHITE,"mob_farms","Otomatik koyun çiftliği.",s("sheep_farm",-9,-1,0,"none"),s("sheep_farm",0,-1,-9,"270"),s("sheep_farm",-9,-1,-11,"180"),s("sheep_farm",-11,-1,-9,"90")),
    ENDERMAN_FARM("enderman_farm","Enderman Farm","Ender İncisi",Items.ENDER_PEARL,Formatting.DARK_PURPLE,"mob_farms","End'de enderman çiftliği.",s("enderman_farm",-10,-1,1,"90"),s("enderman_farm",1,-1,-10,"none"),s("enderman_farm",-10,-1,-21,"270"),s("enderman_farm",-21,-1,-10,"180")),
    BARTERING_FARM("bartering_farm","Bartering Farm","Takas Malları",Items.GOLD_INGOT,Formatting.YELLOW,"mob_farms","Piglin takas çiftliği.",s("bartering_farm",-7,-2,1,"none"),s("bartering_farm",1,-2,-7,"270"),s("bartering_farm",-7,-2,-8,"180"),s("bartering_farm",-8,-2,-7,"90")),
    MOB_FARM("mob_farm","Mob Farm","XP & Loot",Items.ROTTEN_FLESH,Formatting.DARK_GREEN,"mob_farms","Genel mob çiftliği.",s("mob_farm",-9,-1,1,"90"),s("mob_farm",1,-1,-10,"none"),s("mob_farm",-10,-1,-20,"270"),s("mob_farm",-20,-1,-9,"180")),
    BAMBOOM_FARM("bamboom_farm","Bamboom Farm","Bambu (Mega)",Items.BAMBOO,Formatting.GREEN,"mega_farms","Dev bambu çiftliği.",s("rail2",-9,4,38,"none"),s("rail2",2,4,15,"none"),s("rail2",-6,4,-38,"180"),s("rail2",-17,4,-15,"180")),
    KELPM_FARM("kelpm_farm","Kelp Mega Farm","Yosun (Mega)",Items.KELP,Formatting.DARK_AQUA,"mega_farms","Dev yosun çiftliği.",s("kelpm_farm",-9,-1,1,"none"),s("kelpm_farm",1,-1,-9,"270"),s("kelpm_farm",-9,-1,-52,"180"),s("kelpm_farm",-52,-1,-9,"90")),
    REEDSM_FARM("reedsm_farm","Reeds Mega Farm","Kamış (Mega)",Items.SUGAR_CANE,Formatting.AQUA,"mega_farms","Dev kamış çiftliği.",s("railb1",-9,10,8,"none"),s("railb2",8,10,-6,"180"),s("railb1",-6,10,-54,"180"),s("railb2",-54,10,-9,"none")),
    TWISTING_VINES_FARM("twisting_vines_farm","Twisting Vines Mega","Kıvrımlı Asma (Mega)",Items.TWISTING_VINES,Formatting.DARK_AQUA,"mega_farms","Dev kıvrımlı asma.",s("rail2",-9,4,38,"none"),s("rail2",2,4,15,"none"),s("rail2",-6,4,-38,"180"),s("rail2",-17,4,-15,"180")),
    WEEPING_VINES_FARM("weeping_vines_farm","Weeping Vines Mega","Ağlayan Asma (Mega)",Items.WEEPING_VINES,Formatting.DARK_RED,"mega_farms","Dev ağlayan asma.",s("weeping_vines_farm",-28,-1,1,"none"),s("weeping_vines_farm",1,-1,-29,"270"),s("weeping_vines_farm",-29,-1,-17,"180"),s("weeping_vines_farm",-17,-1,-28,"90")),
    ICE_HIGHWAY_MAKER("ice_highway_maker","Ice Highway Maker","Buz Yolu",Items.PACKED_ICE,Formatting.AQUA,"misc","Otomatik buz yolu.",s("ice_highway_maker",-3,0,1,"180"),s("ice_highway_maker",1,0,-4,"90"),s("ice_highway_maker",-4,0,-19,"none"),s("ice_highway_maker",-19,0,-3,"270")),
    MARKER_BLOCK("marker_block","Marker Block","İşaret Bloğu",Items.GLASS,Formatting.AQUA,"misc","Farm alanını işaretler.",s("marker_block",0,0,0,"none"),s("marker_block",0,0,0,"none"),s("marker_block",0,0,0,"none"),s("marker_block",0,0,0,"none"));

    public final String id, displayName, produces, category, description;
    public final Item iconItem;
    public final Formatting color;
    public final StructLoad[] loads;

    FarmDef(String id, String displayName, String produces, Item iconItem, Formatting color,
            String category, String description,
            StructLoad s, StructLoad e, StructLoad n, StructLoad w) {
        this.id=id; this.displayName=displayName; this.produces=produces;
        this.iconItem=iconItem; this.color=color; this.category=category;
        this.description=description;
        this.loads=new StructLoad[]{s,e,n,w};
    }

    private static StructLoad s(String name,int dx,int dy,int dz,String rot){
        return new StructLoad(name,dx,dy,dz,rot);
    }

    public static FarmDef fromId(String id){
        for(FarmDef f:values()) if(f.id.equals(id)) return f;
        return null;
    }

    public static class StructLoad {
        public final String name, rotation;
        public final int dx, dy, dz;
        public StructLoad(String name,int dx,int dy,int dz,String rotation){
            this.name=name; this.dx=dx; this.dy=dy; this.dz=dz; this.rotation=rotation;
        }
        public String javaRot(){
            return switch(rotation){
                case "90"  -> "clockwise_90";
                case "180" -> "180";
                case "270" -> "counterclockwise_90";
                default    -> "none";
            };
        }
    }
}
