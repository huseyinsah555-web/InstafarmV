package com.instafarm;
import com.instafarm.gui.FarmGuideScreen;
import com.instafarm.registry.ModScreenHandlers;
import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.gui.screen.ingame.HandledScreens;

public class InstaFarmClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        HandledScreens.register(ModScreenHandlers.FARM_GUIDE_SCREEN_HANDLER, FarmGuideScreen::new);
    }
}
