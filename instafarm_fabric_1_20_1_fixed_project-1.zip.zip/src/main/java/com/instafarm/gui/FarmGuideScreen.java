package com.instafarm.gui;

import com.instafarm.registry.ModBlocks;
import com.instafarm.registry.ModItems;
import com.instafarm.util.FarmDef;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import java.util.*;

public class FarmGuideScreen extends HandledScreen<FarmGuideScreenHandler> {

    private static final LinkedHashMap<String,List<FarmDef>> CATS = new LinkedHashMap<>();
    static {
        CATS.put("§2Mahsul", List.of(FarmDef.BEETROOT_FARM,FarmDef.BREAD_FARM,FarmDef.CARROT_FARM,
            FarmDef.POTATO_FARM,FarmDef.MELON_FARM,FarmDef.PUMPKIN_FARM,FarmDef.MELON_PUMPKIN_FARM));
        CATS.put("§6Doğa",  List.of(FarmDef.BAMBOO_FARM,FarmDef.CACTUS_FARM,FarmDef.KELP_FARM,
            FarmDef.CANES_FARM,FarmDef.HONEY_FARM,FarmDef.BONE_MEAL_FARM,FarmDef.TWISTING_FARM,FarmDef.WEEPING_FARM));
        CATS.put("§8Blok",  List.of(FarmDef.COBBLESTONE_FARM,FarmDef.STONE_FARM,FarmDef.BASALT_FARM,
            FarmDef.WOOL_FARM,FarmDef.MANUAL_TREE_FARM,FarmDef.AUTO_TREE_FARM));
        CATS.put("§7Maden", List.of(FarmDef.IRON_FARM,FarmDef.GOLD_FARM));
        CATS.put("§cMob",   List.of(FarmDef.COW_FARM,FarmDef.PIG_FARM,FarmDef.SHEEP_FARM,
            FarmDef.ENDERMAN_FARM,FarmDef.BARTERING_FARM,FarmDef.MOB_FARM));
        CATS.put("§5Mega",  List.of(FarmDef.BAMBOOM_FARM,FarmDef.KELPM_FARM,FarmDef.REEDSM_FARM,
            FarmDef.TWISTING_VINES_FARM,FarmDef.WEEPING_VINES_FARM));
        CATS.put("§bDiğer", List.of(FarmDef.ICE_HIGHWAY_MAKER,FarmDef.MARKER_BLOCK));
    }

    private final List<String> catKeys = new ArrayList<>(CATS.keySet());
    private int selCat=0, selFarm=0, scroll=0;
    private static final int W=324,H=234,SB=132,ENTRY_H=20,VISIBLE=8;
    private int bx,by;

    public FarmGuideScreen(FarmGuideScreenHandler h, PlayerInventory inv, Text title) {
        super(h,inv,title);
        backgroundWidth=W; backgroundHeight=H;
    }

    @Override
    protected void init() {
        super.init();
        bx=(width-W)/2; by=(height-H)/2;
        addDrawableChild(ButtonWidget.builder(Text.literal("§a📦 Farm Al"),
            b->giveSelected()).dimensions(bx+W-88,by+H-27,84,19).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("§e🔨 Builder x16"),
            b->giveItem(new ItemStack(ModItems.BUILDER_TOOL,16))).dimensions(bx+W-182,by+H-27,90,19).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("§b📍 Marker x16"),
            b->giveItem(new ItemStack(ModItems.MARKER_TOOL,16))).dimensions(bx+W-276,by+H-27,90,19).build());
    }

    @Override
    protected void drawBackground(DrawContext ctx, float delta, int mx, int my) {
        ctx.fill(0,0,width,height,0xAA000000);
        ctx.fill(bx,by,bx+W,by+H,0xFF1A0A04);
        ctx.fill(bx+2,by+2,bx+W-2,by+H-2,0xFFF2E0AA);
        ctx.fill(bx+2,by+2,bx+W-2,by+20,0xFF3D1800);
        ctx.fill(bx+2,by+20,bx+SB,by+H-31,0xFFD4A85A);
        ctx.fill(bx+SB+2,by+20,bx+W-2,by+H-31,0xFFFAECC8);
        ctx.fill(bx+SB,by+2,bx+SB+2,by+H-2,0xFF5C2800);
        ctx.fill(bx+2,by+H-31,bx+W-2,by+H-2,0xFFD4A85A);
        box(ctx,bx,by,bx+W,by+H,0xFF5C2800);
        box(ctx,bx+2,by+20,bx+SB,by+H-31,0xFF8B4A10);
        box(ctx,bx+SB+2,by+20,bx+W-2,by+H-31,0xFF8B4A10);
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        renderBackground(ctx); super.render(ctx,mx,my,delta);
        ctx.drawCenteredTextWithShadow(textRenderer,
            Text.literal("§6§l📖 Insta Farm V5.0  §8By EndXenoc"),bx+W/2,by+6,0xFFFFD700);
        drawCats(ctx,mx,my); drawList(ctx,mx,my); drawDetail(ctx);
    }

    private void drawCats(DrawContext ctx,int mx,int my) {
        int cx=bx+4,cy=by+22;
        for(int i=0;i<catKeys.size();i++){
            boolean sel=i==selCat;
            ctx.fill(cx,cy,cx+SB-8,cy+11,sel?0xFF7A3A08:0xFFAA7030);
            if(sel)box(ctx,cx,cy,cx+SB-8,cy+11,0xFFFFD700);
            ctx.drawText(textRenderer,Text.literal(catKeys.get(i)),cx+3,cy+2,sel?0xFFFFFF00:0xFF2A1000,false);
            if(mx>=cx&&mx<=cx+SB-8&&my>=cy&&my<=cy+11)ctx.fill(cx,cy,cx+SB-8,cy+11,0x22FFFFFF);
            cy+=13;
        }
    }

    private void drawList(DrawContext ctx,int mx,int my) {
        List<FarmDef> farms=cur();
        int listY=by+22+catKeys.size()*13+4,lx=bx+4,lw=SB-8;
        for(int i=scroll;i<Math.min(farms.size(),scroll+VISIBLE);i++){
            int ey=listY+(i-scroll)*(ENTRY_H-2);
            if(ey+ENTRY_H>by+H-33)break;
            FarmDef d=farms.get(i); boolean sel=i==selFarm;
            ctx.fill(lx,ey,lx+lw,ey+ENTRY_H-3,sel?0x88FFD700:0x22000000);
            if(sel)box(ctx,lx,ey,lx+lw,ey+ENTRY_H-3,0xFFFFD700);
            ctx.drawItem(new ItemStack(d.iconItem),lx+1,ey+1);
            String nm=d.displayName.length()>14?d.displayName.substring(0,12)+"..":d.displayName;
            int col=d.color.getColorValue()!=null?d.color.getColorValue()|0xFF000000:0xFF333333;
            ctx.drawText(textRenderer,Text.literal(nm),lx+20,ey+6,col,false);
            if(mx>=lx&&mx<=lx+lw&&my>=ey&&my<=ey+ENTRY_H-3)ctx.fill(lx,ey,lx+lw,ey+ENTRY_H-3,0x22FFFFFF);
        }
    }

    private void drawDetail(DrawContext ctx) {
        List<FarmDef> farms=cur();
        if(farms.isEmpty()||selFarm>=farms.size())return;
        FarmDef d=farms.get(selFarm);
        int px=bx+SB+6,pw=W-SB-10,py=by+23;
        ctx.drawItemWithoutEntity(new ItemStack(d.iconItem),px+pw/2-8,py+2);
        ctx.drawCenteredTextWithShadow(textRenderer,
            Text.literal(d.displayName).formatted(d.color,Formatting.BOLD),px+pw/2,py+22,0xFFFFFFFF);
        ctx.drawCenteredTextWithShadow(textRenderer,
            Text.literal("§aÜretir: §f"+d.produces),px+pw/2,py+36,0xFF00DD00);
        ctx.fill(px+4,py+49,px+pw-4,py+50,0xFF8B4A10);
        List<String> dl=wrap(d.description,24);
        for(int i=0;i<Math.min(dl.size(),4);i++)
            ctx.drawText(textRenderer,Text.literal(dl.get(i)).formatted(Formatting.DARK_GRAY),px+4,py+54+i*10,0xFF555555,false);
        ctx.fill(px+4,py+100,px+pw-4,py+101,0xFF8B4A10);
        ctx.drawText(textRenderer,Text.literal("§6Nasıl Kullanılır:"),px+4,py+105,0xFFFFAA00,false);
        ctx.drawText(textRenderer,Text.literal("§71. Farm bloğunu yerleştir"),px+4,py+116,0xFF888888,false);
        ctx.drawText(textRenderer,Text.literal("§72. Marker Tool ile işaretle"),px+4,py+126,0xFF888888,false);
        ctx.drawText(textRenderer,Text.literal("§73. Builder Tool ile inşa et"),px+4,py+136,0xFF888888,false);
        ctx.drawCenteredTextWithShadow(textRenderer,
            Text.literal("§b↓ Al butonuyla envanterinden al ↓"),px+pw/2,by+H-40,0xFF55FFFF);
    }

    @Override
    public boolean mouseClicked(double mx,double my,int btn) {
        int cx=bx+4,cy=by+22;
        for(int i=0;i<catKeys.size();i++){
            if(mx>=cx&&mx<=cx+SB-8&&my>=cy&&my<=cy+11){selCat=i;selFarm=0;scroll=0;return true;}
            cy+=13;
        }
        List<FarmDef> farms=cur();
        int listY=by+22+catKeys.size()*13+4;
        for(int i=scroll;i<Math.min(farms.size(),scroll+VISIBLE);i++){
            int ey=listY+(i-scroll)*(ENTRY_H-2);
            if(ey+ENTRY_H>by+H-33)break;
            if(mx>=bx+4&&mx<=bx+4+SB-8&&my>=ey&&my<=ey+ENTRY_H-3){selFarm=i;return true;}
        }
        return super.mouseClicked(mx,my,btn);
    }

    @Override
    public boolean mouseScrolled(double mx,double my,double amount){
        scroll=(int)Math.max(0,Math.min(Math.max(0,cur().size()-VISIBLE),scroll-amount));
        return true;
    }

    private void giveSelected(){
        List<FarmDef> f=cur(); if(selFarm>=f.size())return;
        FarmDef d=f.get(selFarm);
        if(d==FarmDef.MARKER_BLOCK){giveItem(new ItemStack(ModBlocks.MARKER_BLOCK));return;}
        var blk=ModBlocks.getBlock(d); if(blk!=null)giveItem(new ItemStack(blk.asItem()));
    }

    private void giveItem(ItemStack stack){
        if(client!=null&&client.player!=null){
            client.player.getInventory().insertStack(stack.copy());
            client.player.sendMessage(Text.literal("§a✔ "+stack.getName().getString()+" eklendi!"),true);
        }
    }

    private List<FarmDef> cur(){
        return selCat<catKeys.size()?CATS.getOrDefault(catKeys.get(selCat),List.of()):List.of();
    }

    private void box(DrawContext ctx,int x1,int y1,int x2,int y2,int c){
        ctx.fill(x1,y1,x2,y1+1,c);ctx.fill(x1,y2-1,x2,y2,c);
        ctx.fill(x1,y1,x1+1,y2,c);ctx.fill(x2-1,y1,x2,y2,c);
    }

    private List<String> wrap(String t,int max){
        List<String> out=new ArrayList<>(); StringBuilder cur=new StringBuilder();
        for(String w:t.split(" ")){
            if(cur.length()+w.length()>max&&cur.length()>0){out.add(cur.toString().trim());cur=new StringBuilder();}
            cur.append(w).append(' ');
        }
        if(cur.length()>0)out.add(cur.toString().trim());
        return out;
    }

    @Override protected void drawForeground(DrawContext ctx,int mx,int my){}
    @Override public boolean shouldPause(){return false;}
}
