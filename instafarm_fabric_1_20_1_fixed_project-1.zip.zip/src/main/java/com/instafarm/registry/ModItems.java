package com.instafarm.registry;

import com.instafarm.InstaFarm;
import com.instafarm.item.BuilderToolItem;
import com.instafarm.item.FarmGuideItem;
import com.instafarm.item.MarkerToolItem;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModItems {
    public static BuilderToolItem BUILDER_TOOL;
    public static MarkerToolItem  MARKER_TOOL;
    public static FarmGuideItem   FARM_GUIDE;

    public static void register() {
        BUILDER_TOOL = Registry.register(Registries.ITEM,
            new Identifier(InstaFarm.MOD_ID, "builder_tool"),
            new BuilderToolItem(new FabricItemSettings().maxCount(16)));
        MARKER_TOOL = Registry.register(Registries.ITEM,
            new Identifier(InstaFarm.MOD_ID, "marker_tool"),
            new MarkerToolItem(new FabricItemSettings().maxCount(16)));
        FARM_GUIDE = Registry.register(Registries.ITEM,
            new Identifier(InstaFarm.MOD_ID, "farm_guide"),
            new FarmGuideItem(new FabricItemSettings().maxCount(1)));
    }
}
