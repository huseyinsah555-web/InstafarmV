package com.instafarm.item;

import com.instafarm.gui.FarmGuideScreenHandler;
import com.instafarm.registry.ModScreenHandlers;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;
import java.util.List;

public class FarmGuideItem extends Item {
    public FarmGuideItem(Settings settings) { super(settings); }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        if (!world.isClient) {
            user.openHandledScreen(new SimpleNamedScreenHandlerFactory(
                (syncId, inv, player) -> new FarmGuideScreenHandler(syncId, inv),
                Text.literal("§6§lInsta Farm V5.0 Rehberi")));
        }
        return TypedActionResult.success(user.getStackInHand(hand));
    }

    @Override
    public void appendTooltip(ItemStack stack, @Nullable World world, List<Text> tooltip, TooltipContext ctx) {
        tooltip.add(Text.literal("Tüm farm bilgileri burada!").formatted(Formatting.GREEN));
        tooltip.add(Text.literal("Sağ tık → Rehberi aç").formatted(Formatting.GRAY));
    }

    @Override public boolean hasGlint(ItemStack stack) { return true; }
}
