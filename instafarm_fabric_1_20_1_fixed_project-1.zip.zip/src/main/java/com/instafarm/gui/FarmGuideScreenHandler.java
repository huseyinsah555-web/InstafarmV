package com.instafarm.gui;

import com.instafarm.registry.ModScreenHandlers;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;

public class FarmGuideScreenHandler extends ScreenHandler {
    public FarmGuideScreenHandler(int syncId, PlayerInventory inv) {
        super(ModScreenHandlers.FARM_GUIDE_SCREEN_HANDLER, syncId);
        for (int row = 0; row < 3; row++)
            for (int col = 0; col < 9; col++)
                addSlot(new Slot(inv, col + row*9 + 9, 8 + col*18, 194 + row*18));
        for (int col = 0; col < 9; col++)
            addSlot(new Slot(inv, col, 8 + col*18, 252));
    }
    @Override public boolean canUse(PlayerEntity player) { return true; }
    @Override public ItemStack quickMove(PlayerEntity player, int slot) { return ItemStack.EMPTY; }
}
