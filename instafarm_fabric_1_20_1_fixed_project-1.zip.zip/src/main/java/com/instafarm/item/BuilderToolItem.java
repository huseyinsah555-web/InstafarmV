package com.instafarm.item;

import net.minecraft.client.item.TooltipContext;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;
import java.util.List;

public class BuilderToolItem extends Item {
    public BuilderToolItem(Settings settings) { super(settings); }

    @Override
    public void appendTooltip(ItemStack stack, @Nullable World world, List<Text> tooltip, TooltipContext ctx) {
        tooltip.add(Text.literal("Farm bloğuna sağ tıkla → İnşa et!").formatted(Formatting.GREEN));
        tooltip.add(Text.literal("Her kullanımda 1 adet azalır.").formatted(Formatting.GRAY));
    }

    @Override public boolean hasGlint(ItemStack stack) { return true; }
}
