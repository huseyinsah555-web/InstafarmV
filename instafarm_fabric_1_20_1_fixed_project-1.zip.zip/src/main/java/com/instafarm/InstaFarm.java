package com.instafarm;
import com.instafarm.registry.ModBlocks;
import com.instafarm.registry.ModItems;
import com.instafarm.registry.ModScreenHandlers;
import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class InstaFarm implements ModInitializer {
    public static final String MOD_ID = "instafarm";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    @Override
    public void onInitialize() {
        ModBlocks.register();
        ModItems.register();
        ModScreenHandlers.register();
        LOGGER.info("Insta Farm V5.0 Java Edition loaded! By EndXenoc");
    }
}
