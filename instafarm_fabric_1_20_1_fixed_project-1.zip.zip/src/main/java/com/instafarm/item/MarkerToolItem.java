package com.instafarm.item;

import net.minecraft.client.item.TooltipContext;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;
import java.util.List;

public class MarkerToolItem extends Item {
    public MarkerToolItem(Settings settings) { super(settings); }

    @Override
    public void appendTooltip(ItemStack stack, @Nullable World world, List<Text> tooltip, TooltipContext ctx) {
        tooltip.add(Text.literal("Farm bloğuna sağ tık → Alan önizlemesi aç/kapat").formatted(Formatting.YELLOW));
        tooltip.add(Text.literal("İşaretlemek 1 adet harcar.").formatted(Formatting.GRAY));
    }
}
