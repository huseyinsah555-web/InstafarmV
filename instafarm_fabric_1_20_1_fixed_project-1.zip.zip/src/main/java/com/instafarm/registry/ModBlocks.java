package com.instafarm.registry;

import com.instafarm.InstaFarm;
import com.instafarm.block.FarmBlock;
import com.instafarm.block.MarkerBlock;
import com.instafarm.util.FarmDef;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.minecraft.block.Material;
import net.minecraft.item.BlockItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.util.Identifier;
import java.util.LinkedHashMap;
import java.util.Map;

public class ModBlocks {
    public static final Map<FarmDef, FarmBlock> FARM_BLOCKS = new LinkedHashMap<>();
    public static MarkerBlock MARKER_BLOCK;

    public static void register() {
        for (FarmDef def : FarmDef.values()) {
            if (def == FarmDef.MARKER_BLOCK) continue;
            FarmBlock block = new FarmBlock(
                FabricBlockSettings.of(Material.METAL).strength(1.5f,6.0f)
                    .sounds(BlockSoundGroup.METAL).requiresTool(), def);
            Identifier id = new Identifier(InstaFarm.MOD_ID, def.id);
            Registry.register(Registries.BLOCK, id, block);
            Registry.register(Registries.ITEM, id, new BlockItem(block, new FabricItemSettings()));
            FARM_BLOCKS.put(def, block);
        }
        MARKER_BLOCK = new MarkerBlock(
            FabricBlockSettings.of(Material.GLASS).strength(1.2f,4.2f)
                .sounds(BlockSoundGroup.GLASS).nonOpaque()
                .allowsSpawning((s,w,p,t) -> false));
        Identifier mid = new Identifier(InstaFarm.MOD_ID, "marker_block");
        Registry.register(Registries.BLOCK, mid, MARKER_BLOCK);
        Registry.register(Registries.ITEM, mid, new BlockItem(MARKER_BLOCK, new FabricItemSettings()));
        InstaFarm.LOGGER.info("Registered {} farm blocks.", FARM_BLOCKS.size());
    }

    public static FarmBlock getBlock(FarmDef def) { return FARM_BLOCKS.get(def); }
}
