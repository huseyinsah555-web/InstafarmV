package com.instafarm.registry;

import com.instafarm.InstaFarm;
import com.instafarm.gui.FarmGuideScreenHandler;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.util.Identifier;

public class ModScreenHandlers {
    public static ScreenHandlerType<FarmGuideScreenHandler> FARM_GUIDE_SCREEN_HANDLER;

    public static void register() {
        FARM_GUIDE_SCREEN_HANDLER = Registry.register(
            Registries.SCREEN_HANDLER,
            new Identifier(InstaFarm.MOD_ID, "farm_guide"),
            new ScreenHandlerType<>(FarmGuideScreenHandler::new));
    }
}
