package com.instafarm.block;

import com.instafarm.registry.ModItems;
import com.instafarm.util.FarmDef;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.ShapeContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.DirectionProperty;
import net.minecraft.state.property.EnumProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.StringIdentifiable;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;

public class FarmBlock extends Block {

    public static final DirectionProperty FACING = Properties.HORIZONTAL_FACING;
    public static final EnumProperty<MarkerState> MARKER_STATE =
            EnumProperty.of("marker_state", MarkerState.class);

    private final FarmDef def;

    public FarmBlock(Settings settings, FarmDef def) {
        super(settings);
        this.def = def;
        setDefaultState(getStateManager().getDefaultState()
                .with(FACING, Direction.SOUTH)
                .with(MARKER_STATE, MarkerState.IDLE));
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(FACING, MARKER_STATE);
    }

    @Override
    public BlockState getPlacementState(ItemPlacementContext ctx) {
        return getDefaultState()
                .with(FACING, ctx.getHorizontalPlayerFacing().getOpposite())
                .with(MARKER_STATE, MarkerState.IDLE);
    }

    @Override
    public void onPlaced(World world, BlockPos pos, BlockState state,
                          LivingEntity placer, ItemStack itemStack) {
        super.onPlaced(world, pos, state, placer, itemStack);
        if (!world.isClient && placer instanceof PlayerEntity player) {
            String msg = placementWarning();
            if (msg != null) player.sendMessage(Text.literal("§c" + msg), false);
        }
    }

    @Override
    public ActionResult onUse(BlockState state, World world, BlockPos pos,
                               PlayerEntity player, Hand hand, BlockHitResult hit) {
        ItemStack held = player.getStackInHand(hand);
        boolean isBuilder = held.getItem() == ModItems.BUILDER_TOOL;
        boolean isMarker  = held.getItem() == ModItems.MARKER_TOOL;

        if (!isBuilder && !isMarker) return ActionResult.PASS;
        if (world.isClient) return ActionResult.SUCCESS;

        ServerWorld sw = (ServerWorld) world;
        Direction facing = state.get(FACING);
        MarkerState ms   = state.get(MARKER_STATE);
        FarmDef.StructLoad sl = def.loads[dirIdx(facing)];

        if (isMarker) {
            if (ms == MarkerState.IDLE) {
                world.setBlockState(pos, state.with(MARKER_STATE, MarkerState.MARKED));
                runCmd(sw, String.format(
                    "particle minecraft:happy_villager %d %d %d 3 3 3 0.1 40 force",
                    pos.getX()+sl.dx+1, pos.getY()+sl.dy+1, pos.getZ()+sl.dz+1));
                player.sendMessage(Text.literal(
                    "§e[" + def.displayName + "] Alan işaretlendi! Builder Tool ile inşa et."), true);
                if (!player.isCreative()) held.decrement(1);
            } else {
                world.setBlockState(pos, state.with(MARKER_STATE, MarkerState.IDLE));
                player.sendMessage(Text.literal("§c[" + def.displayName + "] İşaret kaldırıldı."), true);
            }
            return ActionResult.SUCCESS;
        }

        // Builder tool -> place structure, remove block, play sound
        runCmd(sw, String.format("place structure instafarm:%s %d %d %d %s",
            sl.name,
            pos.getX()+sl.dx, pos.getY()+sl.dy, pos.getZ()+sl.dz,
            sl.javaRot()));
        runCmd(sw, String.format("playsound minecraft:block.anvil.use master @a %d %d %d 1 1",
            pos.getX(), pos.getY(), pos.getZ()));

        world.removeBlock(pos, false);
        player.sendMessage(Text.literal("§a✔ " + def.displayName + " inşa edildi!"), false);

        if (!player.isCreative()) held.decrement(1);
        return ActionResult.SUCCESS;
    }

    private String placementWarning() {
        return switch (def) {
            case IRON_FARM      -> "Make sure you are far away from any village (130 blocks)";
            case AUTO_TREE_FARM -> "Don't use this farm in dry/warm biomes";
            default             -> null;
        };
    }

    private static void runCmd(ServerWorld world, String cmd) {
        try {
            MinecraftServer srv = world.getServer();
            ServerCommandSource src = srv.getCommandSource().withLevel(2).withSilent();
            srv.getCommandManager().executeWithPrefix(src, cmd);
        } catch (Exception ignored) {}
    }

    private static int dirIdx(Direction d) {
        return switch (d) { case SOUTH->0; case EAST->1; case NORTH->2; case WEST->3; default->0; };
    }

    @Override
    public VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext ctx) {
        return Block.createCuboidShape(0,0,0,16,16,16);
    }

    public FarmDef getFarmDef() { return def; }

    public enum MarkerState implements StringIdentifiable {
        IDLE("idle"), MARKED("marked");
        private final String name;
        MarkerState(String n) { this.name = n; }
        @Override public String asString() { return name; }
    }
}
